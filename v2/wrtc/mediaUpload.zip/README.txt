Code Category : Done without Bugs & Needs Refinements




Requirement

	1) WebRTC API supportive browser

		- Chrome, Firefox, Opera, or Android Mobile Browser

	2) Server Setup for uploading files
		- Node.js ( img_upload.js )



Project Execution

	1) Setup nodeserver with img_upload.js.
	2) Run index.html on locahost/
	3) On Html page, click on "change your photo" link.
	4) Click your picture right now is the option, and capture your image live.

NOTE : The image upload and update is working on Chrome browser only as of now (Due Node.js limitations. The issue can be resolved by implementing image upload using PHP)